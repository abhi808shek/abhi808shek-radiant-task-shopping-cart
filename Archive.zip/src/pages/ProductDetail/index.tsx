const ProductDetail = () => {
  return <div>ProductDetail</div>;
};

export default ProductDetail;
