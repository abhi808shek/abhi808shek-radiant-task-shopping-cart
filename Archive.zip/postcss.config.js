export default {
  plugins: {
    "@tailwindcss/postcss": {}, // Use the new Tailwind PostCSS plugin
    autoprefixer: {},
  },
};
